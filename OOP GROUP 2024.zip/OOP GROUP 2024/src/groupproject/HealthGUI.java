/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package groupproject;

import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

/**
 *
 * @author Filip
 */
public class HealthGUI extends javax.swing.JFrame {
      // List to store users
    private List<User> users = new ArrayList<>();

    // User class to hold user data
    private class User {
        private String name;
        private int age;
        private String id;
        private String gender;

        public User(String name, int age, String id, String gender) {
            this.name = name;
            this.age = age;
            this.id = id;
            this.gender = gender;
        }

        public String getName() {
            return name;
        }

        public int getAge() {
            return age;
        }

        public String getId() {
            return id;
        }

        public String getGender() {
            return gender;
        }
    }
    /**
     * Creates new form healthGUI
     */
    public HealthGUI() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        nameLBL = new javax.swing.JLabel();
        goodHealthLBL = new javax.swing.JLabel();
        ageLBL = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        idLBL = new javax.swing.JLabel();
        nameTF = new javax.swing.JTextField();
        ageTF = new javax.swing.JTextField();
        idTF = new javax.swing.JTextField();
        physicalHealthBTN = new javax.swing.JButton();
        mentalWellBeingBTN = new javax.swing.JButton();
        healthyLifeStyleBTN = new javax.swing.JButton();
        exitBTN = new javax.swing.JButton();
        manRB = new javax.swing.JRadioButton();
        womanRB = new javax.swing.JRadioButton();
        addBTN = new javax.swing.JButton();
        SearchBTN = new javax.swing.JButton();
        deleteBTN = new javax.swing.JButton();
        displayBTN = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(255, 255, 102));
        setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        setForeground(java.awt.Color.white);

        nameLBL.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        nameLBL.setText("Name :");

        goodHealthLBL.setFont(new java.awt.Font("Segoe UI", 3, 18)); // NOI18N
        goodHealthLBL.setForeground(new java.awt.Color(0, 153, 204));
        goodHealthLBL.setText("Good Health ");

        ageLBL.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        ageLBL.setText("Age :");

        idLBL.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        idLBL.setText("ID :");

        physicalHealthBTN.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        physicalHealthBTN.setForeground(new java.awt.Color(255, 0, 255));
        physicalHealthBTN.setText("Physical Health");
        physicalHealthBTN.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                physicalHealthBTNActionPerformed(evt);
            }
        });

        mentalWellBeingBTN.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        mentalWellBeingBTN.setForeground(new java.awt.Color(0, 0, 255));
        mentalWellBeingBTN.setText("Mental Well Being");
        mentalWellBeingBTN.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mentalWellBeingBTNActionPerformed(evt);
            }
        });

        healthyLifeStyleBTN.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        healthyLifeStyleBTN.setForeground(new java.awt.Color(0, 204, 0));
        healthyLifeStyleBTN.setText("Healthy LifeStyle");
        healthyLifeStyleBTN.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                healthyLifeStyleBTNActionPerformed(evt);
            }
        });

        exitBTN.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        exitBTN.setForeground(new java.awt.Color(255, 0, 0));
        exitBTN.setText("Exit");
        exitBTN.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                exitBTNActionPerformed(evt);
            }
        });

        buttonGroup1.add(manRB);
        manRB.setText("Man");

        buttonGroup1.add(womanRB);
        womanRB.setText("Woman");

        addBTN.setBackground(new java.awt.Color(153, 255, 0));
        addBTN.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        addBTN.setText("Add");
        addBTN.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addBTNActionPerformed(evt);
            }
        });

        SearchBTN.setBackground(new java.awt.Color(102, 102, 255));
        SearchBTN.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        SearchBTN.setText("Search");
        SearchBTN.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SearchBTNActionPerformed(evt);
            }
        });

        deleteBTN.setBackground(new java.awt.Color(255, 51, 51));
        deleteBTN.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        deleteBTN.setText("Delete");
        deleteBTN.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteBTNActionPerformed(evt);
            }
        });

        displayBTN.setBackground(new java.awt.Color(255, 255, 102));
        displayBTN.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        displayBTN.setText("Display");
        displayBTN.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                displayBTNActionPerformed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel1.setText("Gender");

        jLabel2.setIcon(new javax.swing.ImageIcon("C:\\Users\\tenhe\\OneDrive\\Pulpit\\GroupProject\\src\\groupproject\\oop.jpg")); // NOI18N

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(216, 216, 216)
                        .addComponent(jLabel4)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(idLBL)
                                    .addComponent(jLabel1))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(idTF, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(0, 0, Short.MAX_VALUE)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(ageLBL)
                                    .addComponent(nameLBL))
                                .addGap(32, 32, 32)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(manRB)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(womanRB)
                                        .addGap(0, 0, Short.MAX_VALUE))
                                    .addComponent(nameTF, javax.swing.GroupLayout.DEFAULT_SIZE, 150, Short.MAX_VALUE)
                                    .addComponent(ageTF))))
                        .addGap(99, 99, 99)
                        .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 149, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(145, 145, 145))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(40, 40, 40)
                        .addComponent(addBTN, javax.swing.GroupLayout.PREFERRED_SIZE, 77, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(28, 28, 28)
                        .addComponent(SearchBTN)
                        .addGap(30, 30, 30)
                        .addComponent(displayBTN)
                        .addGap(35, 35, 35)
                        .addComponent(deleteBTN)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(goodHealthLBL)
                        .addGap(163, 163, 163)))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(healthyLifeStyleBTN, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(mentalWellBeingBTN, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(physicalHealthBTN, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(47, 47, 47))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(exitBTN)
                        .addGap(55, 55, 55))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(39, 39, 39)
                        .addComponent(healthyLifeStyleBTN, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(8, 8, 8)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(nameLBL)
                                    .addComponent(nameTF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(ageLBL)
                                        .addGap(18, 18, 18)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                            .addComponent(jLabel1)
                                            .addComponent(manRB)
                                            .addComponent(womanRB)))
                                    .addComponent(ageTF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(33, 33, 33)
                                .addComponent(physicalHealthBTN, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(goodHealthLBL, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel2)))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(idLBL)
                            .addComponent(idTF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(20, 20, 20)
                        .addComponent(mentalWellBeingBTN, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 24, Short.MAX_VALUE)
                .addComponent(jLabel4)
                .addGap(51, 51, 51)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(addBTN)
                        .addComponent(SearchBTN)
                        .addComponent(displayBTN)
                        .addComponent(deleteBTN))
                    .addComponent(exitBTN))
                .addGap(104, 104, 104))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void physicalHealthBTNActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_physicalHealthBTNActionPerformed
         JOptionPane.showMessageDialog(this, "Navigating to Physical Health section...");
         new PhysicalHealthFrame().setVisible(true);  //declare, create and show in one line
      
        this.setVisible(false); //hide this
        System.out.println("closed"); //testing line
        this.setDefaultCloseOperation(HealthGUI.EXIT_ON_CLOSE);
        this.dispose(); //closes this frame as opposed to setVisible(false);
                       
    }//GEN-LAST:event_physicalHealthBTNActionPerformed

    private void exitBTNActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_exitBTNActionPerformed
        // TODO add your handling code here:
        System.exit(0);
    }//GEN-LAST:event_exitBTNActionPerformed

    private void healthyLifeStyleBTNActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_healthyLifeStyleBTNActionPerformed
        // TODO add your handling code here:
        JOptionPane.showMessageDialog(this, "Navigating to Healthy Life-style section...");
         new HealthyFrame().setVisible(true);
         
           this.setVisible(false); //hide this
        System.out.println("closed"); //testing line
        this.setDefaultCloseOperation(HealthGUI.EXIT_ON_CLOSE);
        this.dispose(); //closes this frame as opposed to setVisible(false);
    }//GEN-LAST:event_healthyLifeStyleBTNActionPerformed

    private void mentalWellBeingBTNActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mentalWellBeingBTNActionPerformed
        // TODO add your handling code here:
            JOptionPane.showMessageDialog(this, "Navigating to Mental Well-Being Health section...");
         new  MentalWellBeingGUI().setVisible(true);  //declare, create and show in one line
      
        this.setVisible(false); //hide this
        System.out.println("closed"); //testing line
        this.setDefaultCloseOperation(HealthGUI.EXIT_ON_CLOSE);
        this.dispose(); //closes this frame as opposed to setVisible(false);
    }//GEN-LAST:event_mentalWellBeingBTNActionPerformed

    private void addBTNActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addBTNActionPerformed
      // Get user input
        String name = nameTF.getText();
        String age = ageTF.getText();
        String id = idTF.getText();
        String gender = manRB.isSelected() ? "Man" : "Woman";

        // Validate inputs
        if (name.isEmpty() || age.isEmpty() || id.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill all the fields.");
            return;
        }

        // Try to parse age to ensure its a valid number
        try {
            int parsedAge = Integer.parseInt(age);
            if (parsedAge <= 0) {
                JOptionPane.showMessageDialog(this, "Age must be a positive number.");
                return;
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Invalid age format. Please enter a valid number.");
            return;
        }

        // Create a new user object and add it to the list
        User newUser = new User(name, Integer.parseInt(age), id, gender);
        users.add(newUser);

        // Show confirmation message
        JOptionPane.showMessageDialog(this, "Added User:\nName: " + name + "\nAge: " + age + "\nID: " + id + "\nGender: " + gender);
        
    }//GEN-LAST:event_addBTNActionPerformed

    private void SearchBTNActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SearchBTNActionPerformed
                // Get the ID entered by the user
        String id = idTF.getText();

        // Search for the user with the matching ID
        User foundUser = null;
        for (User user : users) {
            if (user.getId().equals(id)) {
                foundUser = user;
                break;
            }
        }

        // Display the result
        if (foundUser != null) {
            JOptionPane.showMessageDialog(this, "User Found:\nName: " + foundUser.getName() + 
                "\nAge: " + foundUser.getAge() + "\nID: " + foundUser.getId() + "\nGender: " + foundUser.getGender());
        } else {
            JOptionPane.showMessageDialog(this, "No user found with ID: " + id);
        }
                                             
        
    }//GEN-LAST:event_SearchBTNActionPerformed

    private void deleteBTNActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteBTNActionPerformed
      // Get the ID entered by the user
        String id = idTF.getText();

        // Search and delete the user by ID
        User userToDelete = null;
        for (User user : users) {
            if (user.getId().equals(id)) {
                userToDelete = user;
                break;
            }
        }

        if (userToDelete != null) {
            users.remove(userToDelete);
            JOptionPane.showMessageDialog(this, "Deleted user with ID: " + id);
        } else {
            JOptionPane.showMessageDialog(this, "No user found with ID: " + id);
        }
                                             

    }//GEN-LAST:event_deleteBTNActionPerformed

    private void displayBTNActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_displayBTNActionPerformed
        // TODO add your handling code here:
         // Check if there are any users to display
    if (users.isEmpty()) {
        JOptionPane.showMessageDialog(this, "No users available to display.");
        return;
    }

    // Create a string to display all users
    StringBuilder userDisplay = new StringBuilder("Users List:\n");

    // Iterate over the list and append each user's details
    for (User user : users) {
        userDisplay.append("Name: ").append(user.getName())
                    .append("\nAge: ").append(user.getAge())
                    .append("\nID: ").append(user.getId())
                    .append("\nGender: ").append(user.getGender())
                    .append("\n\n");
    }

    // Show the result in a dialog box
    JOptionPane.showMessageDialog(this, userDisplay.toString());

        
    }//GEN-LAST:event_displayBTNActionPerformed

    /**
     * @param args the command line arguments
     */
 public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new HealthGUI().setVisible(true);
            }
        });
    }



    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton SearchBTN;
    private javax.swing.JButton addBTN;
    private javax.swing.JLabel ageLBL;
    private javax.swing.JTextField ageTF;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JButton deleteBTN;
    private javax.swing.JButton displayBTN;
    private javax.swing.JButton exitBTN;
    private javax.swing.JLabel goodHealthLBL;
    private javax.swing.JButton healthyLifeStyleBTN;
    private javax.swing.JLabel idLBL;
    private javax.swing.JTextField idTF;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JRadioButton manRB;
    private javax.swing.JButton mentalWellBeingBTN;
    private javax.swing.JLabel nameLBL;
    private javax.swing.JTextField nameTF;
    private javax.swing.JButton physicalHealthBTN;
    private javax.swing.JRadioButton womanRB;
    // End of variables declaration//GEN-END:variables
}
