/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package groupproject;

import java.time.LocalDateTime;

/**
 *
 * @author Zakaria
 */
public class ProgressReport {
     private String reportData;
    private LocalDateTime startDate;
    private LocalDateTime endDate;

public  ProgressReport(String reportData, LocalDateTime startDate, LocalDateTime endDate){
    this.reportData = reportData;
    this.startDate = startDate;
    this.endDate = endDate;
}
public String generateReport() {
        return "Report: " + reportData + "\nStart: " + startDate + "\nEnd: " + endDate;
    }

    public String viewReport() {
        return generateReport();
    }
}
 
