/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package groupproject;

import javax.swing.JOptionPane;

/**
 *
 * @author Filip
 */
public class SleepCalcFrame extends javax.swing.JFrame {

    public SleepCalcFrame() {
        initComponents();
    }

    /**
     * Polymorphic method to get sleep advice
     */
    private String sleepAdvice(SleepCalculator calculator) {
        return calculator.recommendSleep();
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        ageLBL = new javax.swing.JLabel();
        ageTF = new javax.swing.JTextField();
        calculateBTN = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        resultTA = new javax.swing.JTextArea();
        jLabel1 = new javax.swing.JLabel();
        backBTN = new javax.swing.JButton();
        exitBTN = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        ageLBL.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        ageLBL.setText("Enter your age :");

        calculateBTN.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        calculateBTN.setForeground(new java.awt.Color(51, 102, 255));
        calculateBTN.setText("Calculate");
        calculateBTN.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                calculateBTNActionPerformed(evt);
            }
        });

        resultTA.setBackground(new java.awt.Color(204, 255, 204));
        resultTA.setColumns(20);
        resultTA.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        resultTA.setLineWrap(true);
        resultTA.setRows(5);
        jScrollPane1.setViewportView(resultTA);

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 255, 51));
        jLabel1.setText("Calculate your Sleep ");

        backBTN.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        backBTN.setText("Back");
        backBTN.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backBTNActionPerformed(evt);
            }
        });

        exitBTN.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        exitBTN.setForeground(new java.awt.Color(255, 0, 0));
        exitBTN.setText("EXIT");
        exitBTN.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                exitBTNActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(backBTN)
                .addGap(18, 18, 18)
                .addComponent(exitBTN)
                .addGap(48, 48, 48))
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(47, 47, 47)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 361, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(ageLBL)
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(ageTF)
                                    .addComponent(calculateBTN, javax.swing.GroupLayout.DEFAULT_SIZE, 116, Short.MAX_VALUE)))))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(135, 135, 135)
                        .addComponent(jLabel1)))
                .addContainerGap(46, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addComponent(jLabel1)
                .addGap(34, 34, 34)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(ageTF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(ageLBL))
                .addGap(18, 18, 18)
                .addComponent(calculateBTN)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 27, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(backBTN)
                    .addComponent(exitBTN))
                .addGap(29, 29, 29))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void calculateBTNActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_calculateBTNActionPerformed
        // TODO add your handling code here:                                      
    try {
        // get the age input from the text field
        int age = Integer.parseInt(ageTF.getText());

        SleepCalculator calculator;

        //which type of calculator to use based on the age
        if (age >= 65) {
            calculator = new SeniorSleepCalculator(age);
        } else if (age >= 18 && age < 25) {
            calculator = new YoungAdultSleepCalculator(age);
        } else if (age < 18) {
            calculator = new ChildSleepCalculator(age);
        } else {
            calculator = new SleepCalculator(age);
        }

        // Call the sleepAdvice method
        String advice = calculator.recommendSleep();

        // Display the recommendation in the result text area
        resultTA.setText(advice);
    } catch (NumberFormatException e) {
        // Handle invalid input
        resultTA.setText("Please enter a valid age.");
    }
    }//GEN-LAST:event_calculateBTNActionPerformed

    private void backBTNActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backBTNActionPerformed
        // TODO add your handling code here:
            JOptionPane.showMessageDialog(this, "Going Back...");
         new  HealthyFrame().setVisible(true); 
      
        this.setVisible(false); //hide this
        System.out.println("closed"); //testing line
        this.setDefaultCloseOperation(HealthGUI.EXIT_ON_CLOSE);
        this.dispose(); //closes this frame as opposed to setVisible(false);
    }//GEN-LAST:event_backBTNActionPerformed

    private void exitBTNActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_exitBTNActionPerformed
        // TODO add your handling code here:
        System.exit(0);
    }//GEN-LAST:event_exitBTNActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new SleepCalcFrame().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel ageLBL;
    private javax.swing.JTextField ageTF;
    private javax.swing.JButton backBTN;
    private javax.swing.JButton calculateBTN;
    private javax.swing.JButton exitBTN;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextArea resultTA;
    // End of variables declaration//GEN-END:variables
}
