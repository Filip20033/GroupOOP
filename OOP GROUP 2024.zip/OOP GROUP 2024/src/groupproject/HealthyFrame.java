/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package groupproject;

import java.io.IOException;
import javax.swing.JOptionPane;

/**
 *
 * @author Filip
 */
public class HealthyFrame extends javax.swing.JFrame {
    private HealthyTips tips; 
  
    public HealthyFrame() {
        initComponents();
         tips = new HealthyTips();  // Create an instance of the healthyTips class  
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel2 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        exitBTN = new javax.swing.JButton();
        quizBtn = new javax.swing.JButton();
        tipsBTN = new javax.swing.JButton();
        saveTipsBTN = new javax.swing.JButton();
        loadBTN = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        displayTipsTA = new javax.swing.JTextArea();
        backBTN = new javax.swing.JButton();
        calcBTN = new javax.swing.JButton();

        jLabel2.setText("jLabel2");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(51, 0, 204));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(51, 255, 51));
        jLabel1.setText("Healthy LifeStyle Menu");

        exitBTN.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        exitBTN.setForeground(new java.awt.Color(255, 51, 51));
        exitBTN.setText("EXIT");
        exitBTN.setPreferredSize(new java.awt.Dimension(72, 23));
        exitBTN.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                exitBTNActionPerformed(evt);
            }
        });

        quizBtn.setBackground(new java.awt.Color(102, 255, 102));
        quizBtn.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        quizBtn.setText("Start Quiz");
        quizBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                quizBtnActionPerformed(evt);
            }
        });

        tipsBTN.setBackground(new java.awt.Color(102, 255, 102));
        tipsBTN.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        tipsBTN.setText("View Tips");
        tipsBTN.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tipsBTNActionPerformed(evt);
            }
        });

        saveTipsBTN.setBackground(new java.awt.Color(153, 153, 255));
        saveTipsBTN.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        saveTipsBTN.setText("Save the Tips on File");
        saveTipsBTN.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                saveTipsBTNActionPerformed(evt);
            }
        });

        loadBTN.setBackground(new java.awt.Color(153, 153, 255));
        loadBTN.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        loadBTN.setText("Display the tips below");
        loadBTN.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                loadBTNActionPerformed(evt);
            }
        });

        displayTipsTA.setEditable(false);
        displayTipsTA.setBackground(new java.awt.Color(204, 255, 204));
        displayTipsTA.setColumns(20);
        displayTipsTA.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        displayTipsTA.setLineWrap(true);
        displayTipsTA.setRows(5);
        jScrollPane2.setViewportView(displayTipsTA);

        backBTN.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        backBTN.setText("Back");
        backBTN.setPreferredSize(new java.awt.Dimension(72, 23));
        backBTN.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backBTNActionPerformed(evt);
            }
        });

        calcBTN.setBackground(new java.awt.Color(204, 204, 204));
        calcBTN.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        calcBTN.setText("Calculate your Sleep");
        calcBTN.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                calcBTNActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane2)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(450, 450, 450)
                        .addComponent(exitBTN, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addContainerGap())
            .addGroup(layout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(loadBTN)
                        .addGap(18, 18, 18)
                        .addComponent(saveTipsBTN, javax.swing.GroupLayout.PREFERRED_SIZE, 155, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(tipsBTN, javax.swing.GroupLayout.PREFERRED_SIZE, 155, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(quizBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 155, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(18, 18, 18)
                .addComponent(backBTN, javax.swing.GroupLayout.DEFAULT_SIZE, 80, Short.MAX_VALUE)
                .addGap(96, 96, 96))
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(104, 104, 104)
                        .addComponent(calcBTN))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(92, 92, 92)
                        .addComponent(jLabel1)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addComponent(jLabel1)
                .addGap(40, 40, 40)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(tipsBTN, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(quizBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(calcBTN)
                .addGap(29, 29, 29)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(loadBTN, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(saveTipsBTN, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(backBTN, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(exitBTN, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(40, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void exitBTNActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_exitBTNActionPerformed
        // TODO add your handling code here:
        System.exit(0);
    }//GEN-LAST:event_exitBTNActionPerformed

    private void quizBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_quizBtnActionPerformed
        // TODO add your handling code here:// Inform the user that the quiz is starting
     JOptionPane.showMessageDialog(this, "Quiz Started!");

    // Create a new quiz and add questions
    HealthyQuiz quiz = new HealthyQuiz();
    quiz.addQuestion("What is the recommended daily intake of water?", "8 glasses");
    quiz.addQuestion("How many hours of sleep is recommended for adults?", "7-9 hours");
    quiz.addQuestion("What is a good source of Vitamin C?", "Citrus fruits");
    quiz.addQuestion("How many minutes of exercise should adults aim for daily?", "30 minutes");
    quiz.addQuestion("What is an example of a whole grain food?", "Brown rice");

    // Start the quiz and calculate the score
    int score = quiz.startQuiz();

    JOptionPane.showMessageDialog(this, "Quiz Completed!\nYour score: " + score + "/" + quiz.getQuestions().size());
    }//GEN-LAST:event_quizBtnActionPerformed

    private void tipsBTNActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tipsBTNActionPerformed
        // TODO add your handling code here:
      HealthyTips tips = new HealthyTips();
    tips.addHealthTip("Drink at least 8 glasses of water a day", "Hydration");
    tips.addHealthTip("It is recommended 7-9hours sleep for adults", "Sleep");
    tips.addHealthTip("Citrus fruits are good source of Vitamin C", "Nutrition");
    tips.addHealthTip("An adult should aim for 30min exercise", "Exercise");
    tips.addHealthTip("Brown rice is a excellent example of whole grain food", "Healthy Eating");

   
    JOptionPane.showMessageDialog(this, "Healthy Tips Started!");

    // Initialize the number of tips shown
    int tipsViewed = 0;

    // Iterate over all the tips
    for (int i = 0; i < tips.fetchHealthTips().size(); i++) {
        HealthyTips.Tip currentTip = tips.fetchHealthTips().get(i);  // Get the current tip

        // Display the current tip
        String message = "Tip " + (i + 1) + ": " + currentTip.toString();
        JOptionPane.showMessageDialog(this, message, "Health Tip", JOptionPane.INFORMATION_MESSAGE);

        // Increment the number of tips viewed
        tipsViewed++;
    }
    JOptionPane.showMessageDialog(this, "You have viewed " + tipsViewed + " health tips.");         
    }//GEN-LAST:event_tipsBTNActionPerformed

    private void saveTipsBTNActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_saveTipsBTNActionPerformed
        // TODO add your handling code here:
        HealthyTips tips = new HealthyTips();
    tips.addHealthTip("Drink at least 8 glasses of water a day", "Hydration");
    tips.addHealthTip("It is recommended 7-9hours sleep for adults", "Sleep");
    tips.addHealthTip("Citrus fruits are good source of Vitamin C", "Nutrition");
    tips.addHealthTip("An adult should aim for 30min exercise", "Exercise");
    tips.addHealthTip("Brown rice is a excellent example of whole grain food", "Healthy Eating");
    try {
        tips.saveToFile("tips.txt");
        JOptionPane.showMessageDialog(this, "Tips saved successfully!");
            } catch (IOException e) {
        JOptionPane.showMessageDialog(this, "Error saving tips: " + e.getMessage());
        }
    }//GEN-LAST:event_saveTipsBTNActionPerformed

    private void loadBTNActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_loadBTNActionPerformed
        // TODO add your handling code here:
    String filename = "tips.txt";

    try {
        tips.loadFromFile(filename);

        displayTipsTA.setText("");

        // Append each loaded tip to the text area
        for (HealthyTips.Tip tip : tips.fetchHealthTips()) {
            displayTipsTA.append(tip.toString() + "\n");
        }
        
        JOptionPane.showMessageDialog(this, "Tips loaded successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
    } catch (IOException e) {
        
        // Show an error message if loading fails
        JOptionPane.showMessageDialog(this, "Error loading tips from file: " + e.getMessage(),
                "Error", JOptionPane.ERROR_MESSAGE);
    }
    
    }//GEN-LAST:event_loadBTNActionPerformed

    private void backBTNActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backBTNActionPerformed
        // TODO add your handling code here:
           JOptionPane.showMessageDialog(this, "Going Back...");
         new  HealthGUI().setVisible(true); 
      
        this.setVisible(false); //hide this
        System.out.println("closed"); //testing line
        this.setDefaultCloseOperation(HealthGUI.EXIT_ON_CLOSE);
        this.dispose(); //closes this frame as opposed to setVisible(false);
    }//GEN-LAST:event_backBTNActionPerformed

    private void calcBTNActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_calcBTNActionPerformed
        // TODO add your handling code here:
         JOptionPane.showMessageDialog(this, "Going to Calculator for sleep...");
         new  SleepCalcFrame().setVisible(true); 
      
        this.setVisible(false); //hide this
        System.out.println("closed"); //testing line
        this.setDefaultCloseOperation(HealthGUI.EXIT_ON_CLOSE);
        this.dispose(); //closes this frame as opposed to setVisible(false);
    }//GEN-LAST:event_calcBTNActionPerformed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(HealthyFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(HealthyFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(HealthyFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(HealthyFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new HealthyFrame().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton backBTN;
    private javax.swing.JButton calcBTN;
    private javax.swing.JTextArea displayTipsTA;
    private javax.swing.JButton exitBTN;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JButton loadBTN;
    private javax.swing.JButton quizBtn;
    private javax.swing.JButton saveTipsBTN;
    private javax.swing.JButton tipsBTN;
    // End of variables declaration//GEN-END:variables
}
