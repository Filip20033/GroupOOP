/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package groupproject;

import java.util.ArrayList;

/**
 *
 * @author Zakaria
 */
public class FitTips {
     private final ArrayList < String > tips;
    
    public FitTips(){
        tips = new ArrayList<>();
    }
    
    public ArrayList< String > fetchFitTips(){
        return tips;
    }
    
    public void addFitTips( String description){
        tips.add(description);
    }
}


