/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package groupproject;

/**
 *
 * @author Filip
 */
class SleepCalculator {
    protected int age;

    public SleepCalculator(int age) {
        this.age = age;
    }

    public String recommendSleep() {
        return "An adult should sleep around 7-9 hours at night.";
    }
}

// Subclass for seniors
class SeniorSleepCalculator extends SleepCalculator {
    public SeniorSleepCalculator(int age) {
        super(age);
    }

    @Override
    public String recommendSleep() {
        if (this.age >= 65) {
            return "As a senior (65+ years), you should sleep around 7-8 hours at night.";
        } else {
            return super.recommendSleep();
        }
    }
}

// Subclass for young adults
class YoungAdultSleepCalculator extends SleepCalculator {
    public YoungAdultSleepCalculator(int age) {
        super(age);
    }

    @Override
    public String recommendSleep() {
        if (this.age >= 18 && this.age < 25) {
            return "As a young adult (18-24 years), you should aim for 8-10 hours of sleep.";
        } else {
            return super.recommendSleep();
        }
    }
}
class ChildSleepCalculator extends SleepCalculator {
    public ChildSleepCalculator(int age) {
        super(age);
    }

    @Override
    public String recommendSleep() {
        if (this.age < 18) {
            return "As a child or teenager, you should sleep around 9-11 hours at night.";
        } else {
            return super.recommendSleep();
        }
    }
}