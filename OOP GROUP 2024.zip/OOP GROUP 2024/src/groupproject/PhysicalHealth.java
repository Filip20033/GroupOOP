/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package groupproject;

import java.util.ArrayList;

/**
 *
 * @author Zakaria
 */
public class PhysicalHealth {
     private ArrayList < FitnessTracker > activityLog;
    private ArrayList < String> goalList;
    private ArrayList < ProgressReport > progressReports;

    public PhysicalHealth(){
        activityLog = new ArrayList<>();
        goalList = new ArrayList<>();
        progressReports = new ArrayList<>();
    }
 
public void logActivityType(FitnessTracker activity){
      activityLog.add(activity);
}

public void setGoal(String goal){
      goalList.add(goal);
}
public ArrayList < ProgressReport > viewProgress(){
return progressReports;
}

}


