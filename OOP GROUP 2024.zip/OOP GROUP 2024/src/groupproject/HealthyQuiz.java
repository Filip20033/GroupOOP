/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Filip
 */

package groupproject;

import java.util.ArrayList;
import javax.swing.JOptionPane;

public class HealthyQuiz {
    private ArrayList<String> questionList;
    private ArrayList<String> correctAnswers;
    private int score;

    // Constructor
    public HealthyQuiz() {
        questionList = new ArrayList<>();
        correctAnswers = new ArrayList<>();
        score = 0;
    }

    // Add a question and its correct answer
    public void addQuestion(String question, String answer) {
        questionList.add(question);
        correctAnswers.add(answer);
    }

    // Start quiiz
    public int startQuiz() {
        score = 0;

        // Iterate through all questions in the quiz
        for (int i = 0; i < questionList.size(); i++) {
            String question = questionList.get(i); // Get the question
            String correctAnswer = correctAnswers.get(i); // Get the correct answer

            // Show question and get user answer using JOptionPane input dialog
            String userAnswer = JOptionPane.showInputDialog(null, "Question " + (i + 1) + ": " + question);

            // Check if the answer is correct
            if (userAnswer != null && userAnswer.equalsIgnoreCase(correctAnswer)) {
                score++; // 
            }
        }

        return score;
    }

    // Get the list of questions
    public ArrayList<String> getQuestions() {
        return questionList;
    }
}
