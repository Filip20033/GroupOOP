/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package groupproject;
/**
 *
 * @author Filip
 */

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class HealthyTips {

    private List<Tip> healthTips = new ArrayList<>();
    
    // Add a health tip
    public void addHealthTip(String description, String category) {
        healthTips.add(new Tip(description, category));
    }

    // Fetch all health tips
    public List<Tip> fetchHealthTips() {
        return healthTips;
    }

    // Search health tips by category
    public List<Tip> searchByCategory(String category) {
        List<Tip> results = new ArrayList<>();
        for (Tip tip : healthTips) {
            if (tip.getCategory().equalsIgnoreCase(category)) {
                results.add(tip);
            }
        }
        return results;
    }

    // Save health tips to a file
    public void saveToFile(String filename) throws IOException {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filename))) {
            for (Tip tip : healthTips) {
                writer.write(tip.getDescription() + "|" + tip.getCategory());
                writer.newLine();
            }
        }
    }

    // Load health tips from a file
    public void loadFromFile(String filename) throws IOException {
        healthTips.clear();
        try (BufferedReader reader = new BufferedReader(new FileReader(filename))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split("\\|");
                if (parts.length == 2) {
                    addHealthTip(parts[0], parts[1]);
                }
            }
        }
    }

    // Tip class to hold individual health tip details
    public static class Tip {
        private String description;
        private String category;

        public Tip(String description, String category) {
            this.description = description;
            this.category = category;
        }

        public String getDescription() {
            return description;
        }

        public String getCategory() {
            return category;
        }

        @Override
        public String toString() {
            return "Tip: " + description + " (Category: " + category + ")";
        }
    }
}
