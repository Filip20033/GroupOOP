/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package groupproject;

/**
 *
 * @author Zakaria
 */
public class FitnessTracker {
     private String activityType;
    private double duration;
    private double caloriesBurned;
    
    public FitnessTracker( String activityType, double duration, double caloriesBurned){
        this.activityType = activityType;
        this.duration = duration;
        this.caloriesBurned = caloriesBurned;
    }
    
    public String getActivityType(){
        return activityType;
    }
    public void addActivityType(String activityType){
        this.activityType = activityType;
    }
    public void editActivityType(double duration, double caloriesBurned){
        this.duration = duration;
        this.caloriesBurned = caloriesBurned;
    }
    
    @Override
    public String toString(){
        return "Activity:  " + activityType + " , Duration: " + duration + " Calories: " + caloriesBurned;
    }
    }
    



