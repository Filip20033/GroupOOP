/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package groupproject;


/**
 *
 * @author Filip
 */
import java.io.IOException;
import java.util.Scanner;

public class HealthyLifestyle {

    private static HealthyQuiz quiz;
    private static HealthyTips tips;

    public static void main(String[] args) {
        quiz = new HealthyQuiz();
        tips = new HealthyTips();
        Scanner scanner = new Scanner(System.in);

        // Initialize some example health tips
        initializeHealthTips();

        while (true) {
            // Display menu options
            System.out.println("\nWelcome to Healthy Lifestyle!");
            System.out.println("1. Take the Quiz");
            System.out.println("2. View Health Tips");
            System.out.println("3. Search Tips by Category");
            System.out.println("4. Save Tips to File");
            System.out.println("5. Load Tips from File");
            System.out.println("6. Exit");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();
            scanner.nextLine();  // Consume newline

            switch (choice) {
                case 1:
                    startQuiz(scanner);
                    break;
                case 2:
                    viewAllTips();
                    break;
                case 3:
                    searchTipsByCategory(scanner);
                    break;
                case 4:
                    saveTipsToFile(scanner);
                    break;
                case 5:
                    loadTipsFromFile(scanner);
                    break;
                case 6:
                    System.out.println("Thank you for using Healthy Lifestyle!");
                    return;  // Exit the program
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    // Initialize some sample health tips
    private static void initializeHealthTips() {
        tips.addHealthTip("Drink at least 8 glasses of water a day", "Hydration");
        tips.addHealthTip("Eat a balanced diet with a variety of fruits and vegetables", "Nutrition");
        tips.addHealthTip("Exercise for at least 30 minutes every day", "Exercise");
        tips.addHealthTip("Get 7-9 hours of sleep each night", "Sleep");
    }

    // Start the quiz and display the score
    private static void startQuiz(Scanner scanner) {
        // Add questions to the quiz
        quiz.addQuestion("What is the recommended daily intake of water?", "8 glasses");
        quiz.addQuestion("How many hours of sleep is recommended for adults?", "7-9 hours");

        int score = quiz.startQuiz();
        System.out.println("Your score: " + score + "/" + quiz.getQuestions().size());
    }

    // View all health tips
    private static void viewAllTips() {
        System.out.println("\nHealth Tips:");
        for (HealthyTips.Tip tip : tips.fetchHealthTips()) {
            System.out.println(tip);
        }
    }

    // Search for tips by category
    private static void searchTipsByCategory(Scanner scanner) {
        System.out.print("Enter category to search for tips (e.g., Hydration, Nutrition, Exercise, Sleep): ");
        String category = scanner.nextLine();
        var searchResults = tips.searchByCategory(category);
        if (searchResults.isEmpty()) {
            System.out.println("No tips found in this category.");
        } else {
            System.out.println("\nHealth Tips in category '" + category + "':");
            for (HealthyTips.Tip tip : searchResults) {
                System.out.println(tip);
            }
        }
    }

    // Save tips to a file
    private static void saveTipsToFile(Scanner scanner) {
        System.out.print("Enter filename to save tips: ");
        String filename = scanner.nextLine();
        try {
            tips.saveToFile(filename);
            System.out.println("Tips saved successfully to " + filename);
        } catch (IOException e) {
            System.out.println("Error saving tips to file: " + e.getMessage());
        }
    }

    // Load tips from a file
    private static void loadTipsFromFile(Scanner scanner) {
        System.out.print("Enter filename to load tips from: ");
        String filename = scanner.nextLine();
        try {
            tips.loadFromFile(filename);
            System.out.println("Tips loaded successfully from " + filename);
        } catch (IOException e) {
            System.out.println("Error loading tips from file: " + e.getMessage());
        }
    }
}